"""Сервис чата: собирает контекст из персонажа и истории, зовёт LLM, пишет в БД."""

from __future__ import annotations

from collections.abc import AsyncIterator

from sqlalchemy.orm import Session

from app.db import models
from app.llm.base import ChatMessage, LLMProvider
from app.llm.factory import get_llm

# Сколько последних сообщений из истории пихаем в контекст LLM
MAX_HISTORY_MESSAGES = 30


def _build_system_prompt(c: models.Character) -> str:
    """Собираем system-prompt из полей персонажа.

    Структурированный вид помогает модели держать характер.
    """
    parts: list[str] = []
    parts.append(f"You are {c.name}.")
    if c.description:
        parts.append(f"About you: {c.description}")
    if c.personality_traits:
        parts.append(f"Personality traits: {c.personality_traits}")
    if c.backstory:
        parts.append(f"Backstory: {c.backstory}")
    if c.system_prompt:
        parts.append(c.system_prompt)
    parts.append(
        "Stay in character at all times. Respond in the user's language. "
        "Do not break the fourth wall by mentioning that you are an AI model."
    )
    return "\n\n".join(parts)


def _load_history(db: Session, conversation_id: str, limit: int) -> list[ChatMessage]:
    rows: list[models.Message] = (
        db.query(models.Message)
        .filter(models.Message.conversation_id == conversation_id)
        .order_by(models.Message.created_at.desc())
        .limit(limit)
        .all()
    )
    rows.reverse()
    return [ChatMessage(role=m.role, content=m.content) for m in rows if m.role in ("user", "assistant", "system")]


def build_context(
    db: Session,
    conversation: models.Conversation,
    user_text: str,
) -> list[ChatMessage]:
    history = _load_history(db, conversation.id, MAX_HISTORY_MESSAGES)
    messages: list[ChatMessage] = [
        ChatMessage(role="system", content=_build_system_prompt(conversation.character)),
        *history,
        ChatMessage(role="user", content=user_text),
    ]
    return messages


def save_message(
    db: Session,
    conversation: models.Conversation,
    role: str,
    content: str,
    *,
    tokens_in: int = 0,
    tokens_out: int = 0,
    model: str | None = None,
) -> models.Message:
    msg = models.Message(
        conversation_id=conversation.id,
        role=role,
        content=content,
        tokens_in=tokens_in,
        tokens_out=tokens_out,
        model=model,
    )
    db.add(msg)
    db.flush()
    return msg


async def reply(
    db: Session,
    conversation: models.Conversation,
    user_text: str,
    *,
    llm: LLMProvider | None = None,
) -> tuple[models.Message, models.Message]:
    """Один цикл: сохранили user, дёрнули LLM, сохранили assistant."""
    llm = llm or get_llm()

    user_msg = save_message(db, conversation, role="user", content=user_text)

    messages = build_context(db, conversation, user_text)
    completion = await llm.complete(
        messages,
        model=conversation.character.model or None,
        temperature=conversation.character.temperature,
    )

    assistant_msg = save_message(
        db,
        conversation,
        role="assistant",
        content=completion.content,
        tokens_in=completion.tokens_in,
        tokens_out=completion.tokens_out,
        model=completion.model,
    )
    db.commit()
    db.refresh(user_msg)
    db.refresh(assistant_msg)
    return user_msg, assistant_msg


async def stream_reply(
    db: Session,
    conversation: models.Conversation,
    user_text: str,
    *,
    llm: LLMProvider | None = None,
) -> AsyncIterator[str]:
    """Стриминг ответа. Сообщения сохраняются после полного завершения стрима.

    Так проще, чем апдейтить запись по чанкам. Если стрим оборвался — assistant
    пишется с тем что успели накопить.
    """
    llm = llm or get_llm()

    save_message(db, conversation, role="user", content=user_text)
    db.commit()

    messages = build_context(db, conversation, user_text)
    accumulated: list[str] = []

    try:
        async for piece in llm.stream(
            messages,
            model=conversation.character.model or None,
            temperature=conversation.character.temperature,
        ):
            accumulated.append(piece)
            yield piece
    finally:
        full = "".join(accumulated)
        if full:
            save_message(
                db,
                conversation,
                role="assistant",
                content=full,
                model=conversation.character.model,
            )
            db.commit()
