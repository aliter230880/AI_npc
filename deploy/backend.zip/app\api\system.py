"""Системные эндпоинты: health, info, seed."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db.session import get_db
from app.llm.factory import get_llm
from app.services.seed import seed_demo_characters

router = APIRouter(tags=["system"])


@router.get("/health")
def health() -> dict:
    return {"status": "ok"}


@router.get("/info")
def info() -> dict:
    s = get_settings()
    llm = get_llm()
    return {
        "app": s.app_name,
        "env": s.app_env,
        "llm_provider": llm.name,
        "default_model": s.llm_default_model,
        "openrouter_configured": bool(s.openrouter_api_key),
    }


@router.post("/seed")
def run_seed(db: Session = Depends(get_db)) -> dict:
    """Создаёт демо-персонажей. Идемпотентно."""
    n = seed_demo_characters(db)
    return {"added": n}
