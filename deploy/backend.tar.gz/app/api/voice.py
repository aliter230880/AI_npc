"""HTTP API для голоса: список голосов и синтез речи."""

from __future__ import annotations

import re

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response

from app.db.schemas import VoiceRead
from app.voice import tts

router = APIRouter(prefix="/voice", tags=["voice"])


_CYRILLIC = re.compile(r"[А-яЁё]")
_CJK = re.compile(r"[\u4e00-\u9fff]")


def _detect_lang(text: str) -> str | None:
    """Грубая детекция языка по содержимому текста — чтобы выбрать правильный голос."""
    if not text:
        return None
    if _CYRILLIC.search(text):
        return "ru"
    if _CJK.search(text):
        return "zh"
    # дефолт английский
    return "en"


def _voice_supports_lang(voice_id: str, target_lang: str) -> bool:
    v = tts.VOICES.get(voice_id)
    return bool(v and v.language == target_lang)


def _switch_voice_to_lang(voice_id: str, target_lang: str) -> str | None:
    """Если выбранный голос на другом языке — пробуем взять одного пола/стиля
    но на нужном языке. Например `en_female_calm` + ru → `ru_female_calm`."""
    src = tts.VOICES.get(voice_id)
    if not src:
        return None
    candidate = f"{target_lang}_{src.gender}_{src.style}"
    if candidate in tts.VOICES:
        return candidate
    # фолбэк — любой голос того языка с тем же полом
    for v in tts.VOICES.values():
        if v.language == target_lang and v.gender == src.gender:
            return v.id
    return None


@router.get("/voices", response_model=list[VoiceRead])
def voices() -> list[VoiceRead]:
    return [
        VoiceRead(id=v.id, name=v.name, language=v.language, gender=v.gender, style=v.style)
        for v in tts.list_voices()
    ]


@router.get("/tts")
async def tts_get(
    text: str = Query(..., min_length=1, max_length=5000),
    voice: str | None = Query(None, description="voice_id; иначе подберём по языку"),
    language: str | None = Query(None, description="iso2 код языка для дефолтного голоса"),
) -> Response:
    """Синтез текста в WAV. GET-вариант удобен для <audio src=...>"""
    # Очищаем текст до выбора голоса — детектим язык по реальному содержимому
    cleaned = tts.clean_text_for_tts(text)
    detected_lang = _detect_lang(cleaned)

    # Если выбранный voice_id не подходит языку текста, переподбираем
    # пресет того же пола/стиля но на нужном языке (например en→ru при русском ответе).
    if voice and detected_lang and not _voice_supports_lang(voice, detected_lang):
        voice = _switch_voice_to_lang(voice, detected_lang) or None

    v = tts.resolve_voice(voice, detected_lang or language)
    if v is None:
        raise HTTPException(status_code=503, detail="No voices available on server")
    try:
        wav = await tts.synthesize_wav(cleaned, v)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        # пустой текст после чистки — отдаём 200 с пустым WAV не имеет смысла, ошибка
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"TTS error: {e}")
    headers = {
        "Cache-Control": "public, max-age=86400",
        "X-Voice-Id": v.id,
        "X-Detected-Lang": detected_lang or "",
    }
    return Response(content=wav, media_type="audio/wav", headers=headers)
