"""Сервис чата: собирает контекст из персонажа, истории и долговременной памяти,
зовёт LLM, пишет в БД, периодически суммаризует и сохраняет воспоминания."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db import models
from app.llm.base import ChatMessage, LLMProvider
from app.llm.factory import get_llm
from app.memory import store as memory_store
from app.memory.summarizer import summarize

log = logging.getLogger(__name__)

# Сколько последних сообщений из истории пихаем в контекст LLM
MAX_HISTORY_MESSAGES = 30


def _build_system_prompt(c: models.Character, memories: list[memory_store.Memory] | None = None) -> str:
    """Собираем system-prompt из полей персонажа + (опционально) релевантной памяти."""
    parts: list[str] = []
    parts.append(f"You are {c.name}.")
    if c.description:
        parts.append(f"About you: {c.description}")
    if c.personality_traits:
        parts.append(f"Personality traits: {c.personality_traits}")
    if c.backstory:
        parts.append(f"Backstory: {c.backstory}")
    if c.system_prompt:
        parts.append(c.system_prompt)

    if memories:
        # подаём память отдельным блоком, чтобы модель легко её игнорировала если не относится к делу
        bullets = "\n".join(f"- {m.text}" for m in memories)
        parts.append(
            "You have memories of past conversations with this user. "
            "Use them when relevant; do not mention that they are 'memories' or 'notes':\n" + bullets
        )

    parts.append(
        "Stay in character at all times. Respond in the user's language. "
        "Do not break the fourth wall by mentioning that you are an AI model."
    )
    return "\n\n".join(parts)


def _load_history(db: Session, conversation_id: str, limit: int) -> list[ChatMessage]:
    rows: list[models.Message] = (
        db.query(models.Message)
        .filter(models.Message.conversation_id == conversation_id)
        .order_by(models.Message.created_at.desc())
        .limit(limit)
        .all()
    )
    rows.reverse()
    return [ChatMessage(role=m.role, content=m.content) for m in rows if m.role in ("user", "assistant", "system")]


def _recall_memories(conversation: models.Conversation, query: str) -> list[memory_store.Memory]:
    """Дёргаем релевантные воспоминания. Не падаем если Qdrant лежит."""
    s = get_settings()
    if not s.memory_enabled:
        return []
    try:
        return memory_store.recall(
            character_id=conversation.character_id,
            user_id=conversation.user_id,
            query=query,
            limit=s.memory_recall_k,
            min_score=s.memory_recall_min_score,
        )
    except Exception as e:
        log.warning("recall failed: %s", e)
        return []


def build_context(
    db: Session,
    conversation: models.Conversation,
    user_text: str,
) -> list[ChatMessage]:
    memories = _recall_memories(conversation, user_text)
    history = _load_history(db, conversation.id, MAX_HISTORY_MESSAGES)
    return [
        ChatMessage(role="system", content=_build_system_prompt(conversation.character, memories)),
        *history,
        ChatMessage(role="user", content=user_text),
    ]


def save_message(
    db: Session,
    conversation: models.Conversation,
    role: str,
    content: str,
    *,
    tokens_in: int = 0,
    tokens_out: int = 0,
    model: str | None = None,
) -> models.Message:
    msg = models.Message(
        conversation_id=conversation.id,
        role=role,
        content=content,
        tokens_in=tokens_in,
        tokens_out=tokens_out,
        model=model,
    )
    db.add(msg)
    db.flush()
    return msg


def _maybe_summarize_async(conversation_id: str) -> None:
    """Запускаем фоновую суммаризацию диалога.

    Суммаризируем когда накопилось достаточно реплик и каждые N сообщений после.
    Берём НОВУЮ сессию SQLAlchemy внутри таска, потому что текущая закрывается
    после ответа клиенту.
    """
    s = get_settings()
    if not s.memory_enabled:
        return

    async def _run():
        from app.db.session import SessionLocal
        sess = SessionLocal()
        try:
            conv = sess.get(models.Conversation, conversation_id)
            if not conv:
                return
            # считаем именно user-сообщения — по ним решаем когда суммаризировать
            user_count = (
                sess.query(models.Message)
                .filter(models.Message.conversation_id == conversation_id)
                .filter(models.Message.role == "user")
                .count()
            )
            every = max(1, s.memory_summarize_every)
            # суммаризуем после каждых `every` реплик пользователя
            if user_count == 0 or user_count % every != 0:
                log.info("memory: skip summarize (user_count=%s every=%s)", user_count, every)
                return
            window = (
                sess.query(models.Message)
                .filter(models.Message.conversation_id == conversation_id)
                .order_by(models.Message.created_at.desc())
                .limit(s.memory_summarize_window)
                .all()
            )
            window.reverse()
            pairs = [(m.role, m.content) for m in window if m.role in ("user", "assistant")]
            if not pairs:
                return
            note = await summarize(pairs)
            if not note:
                log.info("memory: summarize returned SKIP (conv=%s)", conversation_id)
                return
            mid = memory_store.remember(
                character_id=conv.character_id,
                user_id=conv.user_id,
                text=note,
            )
            log.info("memory: stored id=%s (%d chars) char=%s user=%s", mid, len(note), conv.character_id, conv.user_id)
        except Exception as e:
            log.exception("summarize task failed: %s", e)
        finally:
            sess.close()

    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_run())
    except RuntimeError:
        # нет running loop (не должно случаться в FastAPI) — выполняем синхронно
        asyncio.run(_run())


async def reply(
    db: Session,
    conversation: models.Conversation,
    user_text: str,
    *,
    llm: LLMProvider | None = None,
) -> tuple[models.Message, models.Message]:
    """Один цикл: сохранили user, дёрнули LLM, сохранили assistant."""
    llm = llm or get_llm()

    user_msg = save_message(db, conversation, role="user", content=user_text)

    messages = build_context(db, conversation, user_text)
    completion = await llm.complete(
        messages,
        model=conversation.character.model or None,
        temperature=conversation.character.temperature,
    )

    assistant_msg = save_message(
        db,
        conversation,
        role="assistant",
        content=completion.content,
        tokens_in=completion.tokens_in,
        tokens_out=completion.tokens_out,
        model=completion.model,
    )
    db.commit()
    db.refresh(user_msg)
    db.refresh(assistant_msg)

    _maybe_summarize_async(conversation.id)
    return user_msg, assistant_msg


async def stream_reply(
    db: Session,
    conversation: models.Conversation,
    user_text: str,
    *,
    llm: LLMProvider | None = None,
) -> AsyncIterator[str]:
    """Стриминг ответа. Сообщения сохраняются после полного завершения стрима.

    Так проще, чем апдейтить запись по чанкам. Если стрим оборвался — assistant
    пишется с тем что успели накопить.
    """
    llm = llm or get_llm()

    save_message(db, conversation, role="user", content=user_text)
    db.commit()

    messages = build_context(db, conversation, user_text)
    accumulated: list[str] = []

    try:
        async for piece in llm.stream(
            messages,
            model=conversation.character.model or None,
            temperature=conversation.character.temperature,
        ):
            accumulated.append(piece)
            yield piece
    finally:
        full = "".join(accumulated)
        if full:
            save_message(
                db,
                conversation,
                role="assistant",
                content=full,
                model=conversation.character.model,
            )
            db.commit()
        _maybe_summarize_async(conversation.id)
